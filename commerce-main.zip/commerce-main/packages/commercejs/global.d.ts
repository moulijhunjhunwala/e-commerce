declare module '@components/checkout/context'
